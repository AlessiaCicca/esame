from database.DB_connect import DBConnect


class DAO():
    def __init__(self):
        pass
